package main

import "github.com/alist-org/alist/v3/cmd"

func main() {
	cmd.Execute()
}
