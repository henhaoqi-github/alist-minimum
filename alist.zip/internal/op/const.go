package op

const (
	WORK     = "work"
	DISABLED = "disabled"
	RootName = "root"
)
